﻿using Microsoft.AspNetCore.Mvc;
using AngelAngelov_LB_M295_V1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace AngelAngelov_LB_M295_V1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountCategoriesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AccountCategoriesController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> PostAccountCategory([FromBody] AccountCategory accountCategory)
        {
            _context.AccountCategories.Add(accountCategory);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetAccountCategory), new { categoryId = accountCategory.CategoryId }, accountCategory);
        }

        [HttpGet]
        public async Task<IActionResult> GetAllAccountCategories()
        {
            var categories = await _context.AccountCategories.ToListAsync();
            return Ok(categories);
        }

        [HttpGet("{categoryId}")]
        public async Task<IActionResult> GetAccountCategory(Guid categoryId)
        {
            var category = await _context.AccountCategories.FindAsync(categoryId);
            if (category == null)
            {
                return NotFound();
            }
            return Ok(category);
        }

        [HttpPut("{categoryId}")]
        [Authorize]
        public async Task<IActionResult> PutAccountCategory(Guid categoryId, [FromBody] AccountCategory accountCategory)
        {
            if (categoryId != accountCategory.CategoryId)
            {
                return BadRequest();
            }

            _context.Entry(accountCategory).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.AccountCategories.Any(e => e.CategoryId == categoryId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }

        [HttpDelete("{categoryId}")]
        [Authorize]
        public async Task<IActionResult> DeleteAccountCategory(Guid categoryId)
        {
            var category = await _context.AccountCategories.FindAsync(categoryId);
            if (category == null)
            {
                return NotFound();
            }

            _context.AccountCategories.Remove(category);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
