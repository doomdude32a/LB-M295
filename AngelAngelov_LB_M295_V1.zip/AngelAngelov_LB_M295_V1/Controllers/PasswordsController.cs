﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using AngelAngelov_LB_M295_V1.Models;
using System.Runtime.InteropServices;
using Microsoft.AspNetCore.Authorization;

namespace AngelAngelov_LB_M295_V1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PasswordsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PasswordsController(AppDbContext context)
        {
            _context = context;
        }

        // GET:
        [HttpGet]
        public async Task<IActionResult> GetAllPasswords()
        {
            var passwords = await _context.Passwords.ToListAsync();
            return Ok(passwords);
        }

        // GET: 
        [HttpGet("{id}")]
        public async Task<IActionResult> GetPassword(Guid id)
        {
            var password = await _context.Passwords.FindAsync(id);
            if (password == null)
            {
                return NotFound();
            }
            return Ok(password);
        }

        // POST: 
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> PostPassword([FromBody] PasswordEntry passwordEntry)
        {
            _context.Passwords.Add(passwordEntry);
            await _context.SaveChangesAsync();
            return CreatedAtAction("GetPassword", new { id = passwordEntry.PasswordId }, passwordEntry);
        }

        // PUT: 
        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> UpdatePassword(Guid id, [FromBody] PasswordEntry passwordEntry)
        {
            if (id != passwordEntry.PasswordId)
            {
                return BadRequest();
            }

            _context.Entry(passwordEntry).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PasswordExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }

        // DELETE
        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeletePassword(Guid id)
        {
            var passwordEntry = await _context.Passwords.FindAsync(id);
            if (passwordEntry == null)
            {
                return NotFound();
            }

            _context.Passwords.Remove(passwordEntry);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private bool PasswordExists(Guid id)
        {
            return _context.Passwords.Any(e => e.PasswordId == id);
        }
    }
}
