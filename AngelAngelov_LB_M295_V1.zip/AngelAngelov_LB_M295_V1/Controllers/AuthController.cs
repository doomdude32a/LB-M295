﻿using BCrypt.Net;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

[Route("api/[controller]")]
[ApiController]
public class AuthController : ControllerBase
{
    private readonly UserManager<IdentityUser> _userManager;
    private readonly IConfiguration _configuration;
    private readonly JWT _jwt;

    public AuthController(UserManager<IdentityUser> userManager, IConfiguration configuration, JWT jwt)
    {
        _userManager = userManager;
        _configuration = configuration;
        _jwt = jwt;
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] UserRegistrationDto userRegistration)
    {
        
        var hashedPassword = BCrypt.Net.BCrypt.HashPassword(userRegistration.Password);

        
        var user = new IdentityUser { UserName = userRegistration.Username };
        var result = await _userManager.CreateAsync(user, hashedPassword);

        if (result.Succeeded)
        {
            
            return Ok(new { Message = "User registered successfully!" });
        }
        else
        {
            return BadRequest(result.Errors);
        }
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] UserLoginDto userLogin)
    {
        var user = await _userManager.FindByNameAsync(userLogin.Username);
        if (user != null)
        {
            
            var verified = BCrypt.Net.BCrypt.Verify(userLogin.Password, user.PasswordHash);
            if (verified)
            {
                var token = _jwt.GenerateToken(userLogin.Username);
                return Ok(new { Token = token });
            }
        }

        return Unauthorized();
    }
}


public class UserRegistrationDto
{
    public string Username { get; set; }
    public string Password { get; set; }
}

public class UserLoginDto
{
    public string Username { get; set; }
    public string Password { get; set; }
}
