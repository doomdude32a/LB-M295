﻿using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;

namespace AngelAngelov_LB_M295_V1.Models
{
    public class AccountCategory : DbContext
    {
        [Key]
        public Guid CategoryId { get; set; } // Eindeutige ID für die Kategorie

        [Required]
        public Guid AccountId { get; set; } // Verknüpft mit einem Benutzerkonto

        [Required]
        public string CategoryName { get; set; } // Name der Kategorie

        public DateTime CreationDate { get; set; } // Erstellungsdatum der Kategorie

        public DateTime ModificationDate { get; set; } // Datum der letzten Änderung
    }
}
