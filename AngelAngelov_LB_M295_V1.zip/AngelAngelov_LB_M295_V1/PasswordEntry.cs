﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;

public class PasswordEntry : DbContext
{
    [Key]
    public Guid PasswordId { get; set; }
    [Required]
    public string EncryptedPassword { get; set; }
   
}
