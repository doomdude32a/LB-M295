﻿using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;

namespace AngelAngelov_LB_M295_V1.Models
{
    public class Account : DbContext
    {
        [Key]
        public Guid AccountId { get; set; }
        [Required]
        public string Username { get; set; }
        public string EncryptedPassword { get; set; }
        public string Platform { get; set; }
    }
}
