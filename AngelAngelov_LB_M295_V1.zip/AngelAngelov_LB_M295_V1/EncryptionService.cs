﻿using System.Security.Cryptography;
using System.Text;
using System;
using Microsoft.EntityFrameworkCore;

public static class EncryptionService 
{
    
    public static string EncryptPassword(string password, string key)
    {
        
        var keyBytes = Encoding.UTF8.GetBytes(key);
        using var aes = Aes.Create();
        aes.Key = keyBytes;
        var iv = aes.IV;

        using var encryptor = aes.CreateEncryptor(aes.Key, iv);
        using var ms = new MemoryStream();
        using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
        using (var sw = new StreamWriter(cs))
        {
            sw.Write(password);
        }

        var encryptedPasswordBytes = ms.ToArray();
        var result = Convert.ToBase64String(iv) + ":" + Convert.ToBase64String(encryptedPasswordBytes);
        return result;
    }

    public static string DecryptPassword(string encryptedPasswordWithIv, string key)
    {
        var split = encryptedPasswordWithIv.Split(':');
        var iv = Convert.FromBase64String(split[0]);
        var encryptedPassword = Convert.FromBase64String(split[1]);
        var keyBytes = Encoding.UTF8.GetBytes(key);

        using var aes = Aes.Create();
        aes.Key = keyBytes;
        aes.IV = iv;

        using var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
        using var ms = new MemoryStream(encryptedPassword);
        using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
        using var sr = new StreamReader(cs);
        var result = sr.ReadToEnd();
        return result;
    }
}
